Error1 = zeros(20,0);
dt = zeros(20,0);
n = 0;
for i = [6,11,21,201,501]
    n = n+1;
    [errout,xo,to,Uo] = heatCN(1000001,i,0.05,1,5,0);
    Error1(n) = errout;
    dt(n) = 5/(i-1);
end
Error1 = log10(Error1)


Error2 = zeros(20,0);
j=0;
for i = [6,11,21,201,501]
    j=j+1;
    [errout,xo,to,Uo] = heatBTCS(1000001,i,0.05,1,5,0);
    Error2(j) = errout;
    dt(j) = 5/(i-1);
 end
 Error2 = log10(Error2)
 dt = log10(dt);

plot(dt,Error1)
hold on
plot(dt,Error2)
hold off
